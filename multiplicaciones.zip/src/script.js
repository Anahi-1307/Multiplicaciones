function multiplicar(num1, num2) {
      return num1 * num2;
      }

      // Ejemplo de uso
      const resultado = multiplicar(5, 3);
      console.log("El resultado de la multiplicación es:", resultado);
      
}